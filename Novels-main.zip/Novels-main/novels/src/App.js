import logo from './logo.svg';
import './App.css';

import AllRoutes from './Pages/Allroutes';
function App() {
  return (
    <div className="App">
        <AllRoutes/>
    </div>
  );
}

export default App;
